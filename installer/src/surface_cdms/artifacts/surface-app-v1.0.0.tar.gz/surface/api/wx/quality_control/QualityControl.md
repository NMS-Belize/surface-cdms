# Quality Control (QC) System – Design & Flow

This module implements a **deterministic, tier-aware, auditable Quality Control (QC) pipeline** for meteorological observations.

Each observation is evaluated independently using:

- **STEP check**
- **RANGE check**
- **PERSISTENCE check**

Each check is executed independently, and results are aggregated using a strict worst-case priority model.

---

# Design Goals

- Deterministic results
- Explicit threshold provenance
- Tier-aware validation (Custom / Reference / Global)
- Strict failure semantics
- Timezone-safe persistence logic
- Zero hidden fallback behavior

---

# High-Level Architecture

```
quality_control/
│
├── qc_check.py        # Orchestration / entrypoint
├── evaluators.py      # Pure QC decision logic
├── thresholds.py      # Threshold resolution (no fallback merging)
└── helpers.py         # Time handling & DB helpers
```

Each module has a single responsibility.

---

# Execution Flow

For each observation:

1. Resolve STEP, RANGE, and PERSISTENCE thresholds
2. Normalize timestamps to UTC
3. Evaluate STEP
4. Evaluate RANGE
5. Evaluate PERSISTENCE
6. Aggregate final QC flag

All checks are independent. No check mutates another.

---

# Entry Point – `qc_thresholds()`

**File:** `qc_check.py`

```python
qc_thresholds(row, station_id, variable_id, month, data_batch)
```

## Responsibilities

- Resolve thresholds (all tiers independently)
- Normalize timestamps to UTC
- Execute evaluators
- Combine results into a final QC flag

---

## Output Contract (DO NOT CHANGE)

```python
[
    step_flag,
    step_message,
    range_flag,
    range_message,
    persist_flag,
    persist_message,
    final_flag
]
```

This structure is relied upon by downstream insert logic.

---

# Threshold Resolution

**File:** `thresholds.py`

Thresholds are resolved independently from three tiers:

1. **Custom station threshold**
2. **Reference station threshold**
3. **Global variable threshold**

⚠️ Important:

- No downward fallback logic is applied.
- All tiers are retrieved independently.
- Missing tiers do not automatically inherit from others.

Each resolver:

- Attaches prefixed keys:
  - `cus_*`
  - `ref_*`
  - `glob_*`
- Stores a combined description string.

---

# STEP Check

**File:** `evaluators.py`

## Purpose

Detect unrealistic jumps between consecutive values.

### Input

```python
diff_value = current_value - previous_value
```

---

## Tier Logic

STEP evaluation follows strict tier validation:

### 1️⃣ No thresholds exist at all

→ `NOT_CHECKED`

---

### 2️⃣ Global threshold missing

Global is mandatory.

→ `NOT_CHECKED`

---

### 3️⃣ Global fails

If:

```
diff_value < glob_min OR diff_value > glob_max
```

→ `BAD`

---

### 4️⃣ Global passes

Then:

- If reference tier missing → `SUSPICIOUS`
- If reference fails → `SUSPICIOUS`
- If custom tier missing → `SUSPICIOUS`
- If custom fails → `SUSPICIOUS`

---

### 5️⃣ All tiers exist AND pass

→ `GOOD`

---

# Previous-value lookup for STEP QC

STEP QC needs the previous valid measured value.

During bulk ingestion, `insert_raw_data.get_data()` collects one request per station/variable group and calls:

```python
get_prev_measured_bulk(prev_requests, lookback_days=30)
```

The optimized manual-data import therefore searches up to 30 days before the first observation in each group.

The helper's default is seven days:

```python
def get_prev_measured_bulk(requests, lookback_days=7):
```

The manual-data import explicitly overrides that default with `lookback_days=30`.

The bulk lookup returns:

```python
(previous_datetime, previous_measured)
```

or:

```python
(None, None)
```

`(None, None)` means that no valid measured value was found within the requested lookback window. It is an intentional result and must not trigger one database query for every observation.

When `previous_db_record` is supplied to `evaluate_step_qc()`:

- Use the supplied tuple, including `(None, None)`.
- Call `get_prev_measured()` only when `previous_db_record` was not supplied.
- Avoid per-observation fallback queries during bulk imports. Under database load, those queries can become very slow and can block the entire import task.

The intended logic is:

```python
# Use the bulk result whenever the caller supplied one.
if previous_db_record is not None:
    diff_value_date, prev_measured = previous_db_record
else:
    # This path is for older callers that do not preload the value.
    diff_value_date, prev_measured = get_prev_measured(
        row_datetime_utc,
        station_id,
        variable_id,
    )

if is_missing(prev_measured):
    diff_value = None
elif prev_measured is not None:
    diff_value = round(float(value) - float(prev_measured), 3)
```

If the lookback period changes, update both the call in `insert_raw_data.py` and this documentation.

---

# RANGE Check

**File:** `evaluators.py`

## Purpose

Ensure value is physically plausible.

Logic is identical to STEP, but applied to:

```
range_min ≤ value ≤ range_max
```

### Rules

- Global mandatory
- Global fail → `BAD`
- Missing or failing reference → `SUSPICIOUS`
- Missing or failing custom → `SUSPICIOUS`
- All tiers present and pass → `GOOD`
- No thresholds at all → `NOT_CHECKED`

---

# PERSISTENCE Check

**Files:** `evaluators.py`, `helpers.py`

## Purpose

Detect flatlined or frozen sensors.

---

# Persistence Window

Let `t₀` be the current observation timestamp (UTC).

For each configured tier:

```
window_start = t₀ − window_hours
window_end   = t₀
```

Half-open interval:

```
window_start ≤ datetime < window_end
```

The current value at `t₀` is always manually included.

---

# Data Sources Used

Variance is computed from:

1. Historical DB data (`raw_data`)
2. Earlier values in the current batch
3. Current observation

All timestamps are normalized to UTC.

---

# Variance Calculation

```
variance = max(values) − min(values)
```

---

# Tier Evaluation Rules

Each tier (Global, Reference, Custom) is evaluated independently.

For a tier to be valid:

- Both `window` AND `minimum_variance` must exist.
- Partial configuration → treated as not configured.

---

## Decision Logic

### 1️⃣ No valid tiers exist

→ `NOT_CHECKED`

---

### 2️⃣ For each valid tier:

If:

```
variance < minimum_variance
```

→ Immediately `BAD`

(Equality is NOT considered failure.)

---

### 3️⃣ If all valid tiers pass

→ `GOOD`

---

⚠️ Unlike STEP and RANGE:

- Global is NOT mandatory.
- Missing tiers do NOT cause `SUSPICIOUS`.
- Only failure produces `BAD`.

---

# Timezone Handling

All persistence calculations operate in UTC.

Rules:

- Station UTC offset (minutes) is retrieved.
- Naive datetimes are assumed station-local.
- Localized using station offset.
- Converted to UTC.
- Batch records are converted before evaluation.

This ensures DB and batch windows align perfectly.

---

# Final QC Aggregation

**File:** `evaluators.py`

Aggregation follows strict worst-case priority:

```
If any BAD → BAD
Else if any SUSPICIOUS → SUSPICIOUS
Else if any GOOD → GOOD
Else → NOT_CHECKED
```

Severity order:

```
BAD > SUSPICIOUS > GOOD > NOT_CHECKED
```

This guarantees conservative data validation.

---

# Key Behavioral Differences Between Checks

| Feature                | STEP | RANGE | PERSIST |
|------------------------|------|-------|---------|
| Global mandatory       | Yes  | Yes   | No      |
| Missing ref     | SUSPICIOUS | SUSPICIOUS | Ignored |
| Missing custom     | SUSPICIOUS | SUSPICIOUS | Ignored |
| Any tier failure       | BAD or SUSPICIOUS | BAD or SUSPICIOUS | BAD |
| Equality fails         | No  | No   | No (<) |
| Partial config allowed | No   | No    | No      |

---

# System Guarantees

- Deterministic: Same input → same output
- Tier-aware: Provenance always known
- No silent fallback
- No double counting in windows
- Conservative by design
- Extendable for additional QC tests

---

# Extending the QC System

To add a new QC check:

1. Create threshold resolver
2. Implement evaluator
3. Add call inside `qc_thresholds()`
4. Update final aggregation if needed

No existing logic needs modification.

---

# Summary

This QC pipeline:

- Separates resolution from evaluation
- Uses strict tier validation
- Applies conservative final aggregation
- Ensures timezone-safe persistence analysis
- Avoids implicit threshold inheritance
- Preserves a stable output contract